"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Sparkles, RefreshCcw } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useUser } from "@/context/user-context"
import type { AIRecommendation } from "@/lib/ai-recommendation-service"

interface AIRecommendationFormProps {
  onRecommendationsGenerated: (recommendations: AIRecommendation) => void
}

export default function AIRecommendationForm({ onRecommendationsGenerated }: AIRecommendationFormProps) {
  const { user } = useUser()
  const { toast } = useToast()
  const [prompt, setPrompt] = useState("")
  const [energyLevel, setEnergyLevel] = useState([50])
  const [experimentalLevel, setExperimentalLevel] = useState([50])
  const [loading, setLoading] = useState(false)

  const handleGenerate = async () => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please log in to get personalized recommendations",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      const response = await fetch("/api/ai/recommendations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.id,
          prompt,
          energyLevel: energyLevel[0],
          experimentalLevel: experimentalLevel[0],
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate recommendations")
      }

      const data = await response.json()
      onRecommendationsGenerated(data)
    } catch (error) {
      console.error("Error generating recommendations:", error)
      toast({
        title: "Error",
        description: "Failed to generate recommendations. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const getEnergyLevelLabel = (value: number) => {
    if (value < 25) return "Calm"
    if (value < 50) return "Relaxed"
    if (value < 75) return "Energetic"
    return "Intense"
  }

  const getExperimentalLevelLabel = (value: number) => {
    if (value < 25) return "Mainstream"
    if (value < 50) return "Familiar"
    if (value < 75) return "Adventurous"
    return "Experimental"
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Tell us what you're looking for</CardTitle>
        <CardDescription>
          Be specific about genres, moods, artists you like, or activities you're doing.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          placeholder="e.g., 'I'm looking for upbeat electronic music with female vocals for my morning workout' or 'Something similar to Radiohead but with more jazz influences'"
          className="min-h-[120px]"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
        />

        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Energy Level</Label>
              <span className="text-sm text-muted-foreground">{getEnergyLevelLabel(energyLevel[0])}</span>
            </div>
            <Slider value={energyLevel} onValueChange={setEnergyLevel} max={100} step={1} />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Experimental vs. Mainstream</Label>
              <span className="text-sm text-muted-foreground">{getExperimentalLevelLabel(experimentalLevel[0])}</span>
            </div>
            <Slider value={experimentalLevel} onValueChange={setExperimentalLevel} max={100} step={1} />
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleGenerate} disabled={loading || !user} className="w-full gap-2">
          {loading ? (
            <>
              <RefreshCcw className="h-4 w-4 animate-spin" />
              Generating recommendations...
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4" />
              Generate Recommendations
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

