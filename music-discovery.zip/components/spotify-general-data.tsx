"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { ReloadIcon } from "@radix-ui/react-icons"

interface Album {
  id: string
  name: string
  images: { url: string }[]
}

interface Playlist {
  id: string
  name: string
  images: { url: string }[]
}

export function SpotifyGeneralData() {
  const [newReleases, setNewReleases] = useState<Album[]>([])
  const [featuredPlaylists, setFeaturedPlaylists] = useState<Playlist[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchSpotifyData()
  }, [])

  async function fetchSpotifyData() {
    setIsLoading(true)
    setError(null)
    try {
      const response = await fetch("/api/spotify/general")
      const text = await response.text() // Önce text olarak alalım

      let data
      try {
        data = JSON.parse(text) // JSON parse etmeyi deneyelim
      } catch (e) {
        console.error("Failed to parse JSON:", text)
        throw new Error("Invalid JSON response")
      }

      if (!response.ok) {
        throw new Error(data.error || `HTTP error! status: ${response.status}`)
      }

      setNewReleases(data.newReleases || [])
      setFeaturedPlaylists(data.featuredPlaylists || [])
    } catch (e) {
      console.error("Error fetching Spotify data:", e)
      setError(e.message || "Failed to load Spotify data. Please try again later.")
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-[300px]">
        <ReloadIcon className="mr-2 h-4 w-4 animate-spin" /> Loading...
      </div>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>New Releases</CardTitle>
          <CardDescription>Check out the latest album releases</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px]">
            {newReleases.length > 0 ? (
              newReleases.map((album) => (
                <div key={album.id} className="flex items-center space-x-4 mb-4">
                  <img
                    src={album.images[0]?.url || "/placeholder.svg"}
                    alt={album.name}
                    className="w-16 h-16 object-cover rounded"
                  />
                  <div>
                    <p className="font-semibold">{album.name}</p>
                  </div>
                </div>
              ))
            ) : (
              <p>No new releases available.</p>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Featured Playlists</CardTitle>
          <CardDescription>Discover curated playlists by Spotify</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px]">
            {featuredPlaylists.length > 0 ? (
              featuredPlaylists.map((playlist) => (
                <div key={playlist.id} className="flex items-center space-x-4 mb-4">
                  <img
                    src={playlist.images[0]?.url || "/placeholder.svg"}
                    alt={playlist.name}
                    className="w-16 h-16 object-cover rounded"
                  />
                  <div>
                    <p className="font-semibold">{playlist.name}</p>
                  </div>
                </div>
              ))
            ) : (
              <p>No featured playlists available.</p>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  )
}

