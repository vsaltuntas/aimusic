"use client"

import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Plus, Info } from "lucide-react"

// Mock data for featured artists
const featuredArtists = [
  {
    id: 1,
    name: "Cosmic Harmony",
    image: "/placeholder.svg?height=400&width=400",
    genres: ["Electronic", "Ambient", "Downtempo"],
    followers: "1.2M",
    topTrack: "Stellar Dreams",
    description: "Pioneering the fusion of electronic and ambient soundscapes.",
  },
  {
    id: 2,
    name: "Neon Pulse",
    image: "/placeholder.svg?height=400&width=400",
    genres: ["Synthwave", "Retrowave", "Electronic"],
    followers: "950K",
    topTrack: "Midnight Drive",
    description: "Bringing back the nostalgic sounds of the 80s with a modern twist.",
  },
  {
    id: 3,
    name: "Velvet Echoes",
    image: "/placeholder.svg?height=400&width=400",
    genres: ["Dream Pop", "Shoegaze", "Indie"],
    followers: "780K",
    topTrack: "Ethereal Whispers",
    description: "Creating dreamy soundscapes that transport listeners to another dimension.",
  },
  {
    id: 4,
    name: "Urban Rhapsody",
    image: "/placeholder.svg?height=400&width=400",
    genres: ["Hip Hop", "Jazz Rap", "Neo Soul"],
    followers: "1.5M",
    topTrack: "City Lights",
    description: "Blending hip hop beats with jazz influences for a unique urban sound.",
  },
]

export default function FeaturedArtists() {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold">Trending Artists</h2>
      <p className="text-muted-foreground">Discover the artists making waves in the music scene right now.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {featuredArtists.map((artist) => (
          <Card key={artist.id} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="relative aspect-square">
                <Image src={artist.image || "/placeholder.svg"} alt={artist.name} fill className="object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-4">
                  <h3 className="text-xl font-bold text-white mb-1">{artist.name}</h3>
                  <p className="text-white/80 text-sm mb-3">{artist.followers} followers</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {artist.genres.map((genre, i) => (
                      <Badge key={i} variant="outline" className="text-xs text-white border-white/30 bg-white/10">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" className="gap-1">
                      <Play className="h-4 w-4" fill="currentColor" /> Play
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-1 bg-white/10 border-white/30 text-white hover:bg-white/20"
                    >
                      <Plus className="h-4 w-4" /> Follow
                    </Button>
                    <Button
                      size="icon"
                      variant="outline"
                      className="ml-auto bg-white/10 border-white/30 text-white hover:bg-white/20"
                    >
                      <Info className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

