"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { LineChart, PieChart, RefreshCcw, Calendar, Clock, Music } from "lucide-react"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendItem,
  ChartBar,
  ChartLine,
  ChartPie,
  ChartGrid,
  ChartXAxis,
  ChartYAxis,
} from "@/components/ui/chart"

// Mock data for charts
const listeningData = [
  { name: "Mon", hours: 2.5 },
  { name: "Tue", hours: 1.8 },
  { name: "Wed", hours: 3.2 },
  { name: "Thu", hours: 2.1 },
  { name: "Fri", hours: 4.5 },
  { name: "Sat", hours: 5.2 },
  { name: "Sun", hours: 3.7 },
]

const genreData = [
  { name: "Electronic", value: 35 },
  { name: "Rock", value: 25 },
  { name: "Hip Hop", value: 20 },
  { name: "Pop", value: 15 },
  { name: "Jazz", value: 5 },
]

const moodData = [
  { month: "Jan", energetic: 45, calm: 30, melancholic: 25 },
  { month: "Feb", energetic: 50, calm: 25, melancholic: 25 },
  { month: "Mar", energetic: 35, calm: 40, melancholic: 25 },
  { month: "Apr", energetic: 30, calm: 45, melancholic: 25 },
  { month: "May", energetic: 55, calm: 30, melancholic: 15 },
  { month: "Jun", energetic: 60, calm: 25, melancholic: 15 },
]

export default function MusicInsights() {
  const [activeTab, setActiveTab] = useState("listening")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Your Music Insights</h2>
          <p className="text-muted-foreground">AI-powered analytics based on your listening habits</p>
        </div>
        <Button variant="outline" size="sm" className="gap-1">
          <RefreshCcw className="h-4 w-4" /> Refresh
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="listening" className="gap-1">
            <Clock className="h-4 w-4" /> Listening Time
          </TabsTrigger>
          <TabsTrigger value="genres" className="gap-1">
            <PieChart className="h-4 w-4" /> Genres
          </TabsTrigger>
          <TabsTrigger value="moods" className="gap-1">
            <LineChart className="h-4 w-4" /> Mood Trends
          </TabsTrigger>
        </TabsList>

        <TabsContent value="listening" className="space-y-4">
          <Card>
            <CardContent className="pt-6">
              <div className="h-[300px]">
                <ChartContainer>
                  <ChartTooltip>
                    <ChartTooltipContent />
                  </ChartTooltip>
                  <ChartGrid />
                  <ChartXAxis dataKey="name" />
                  <ChartYAxis />
                  <ChartBar dataKey="hours" data={listeningData} fill="hsl(var(--primary))" radius={4} />
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-3 rounded-full bg-primary/10">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Weekly Average</p>
                  <p className="text-2xl font-bold">3.2 hours</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-3 rounded-full bg-primary/10">
                  <Calendar className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Most Active Day</p>
                  <p className="text-2xl font-bold">Saturday</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-3 rounded-full bg-primary/10">
                  <Music className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Songs Played</p>
                  <p className="text-2xl font-bold">247 this week</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="genres">
          <Card>
            <CardContent className="pt-6">
              <div className="h-[300px] flex items-center justify-center">
                <div className="w-[300px]">
                  <ChartContainer>
                    <ChartTooltip>
                      <ChartTooltipContent />
                    </ChartTooltip>
                    <ChartPie
                      data={genreData}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                    />
                    <ChartLegend verticalAlign="middle" align="right" layout="vertical">
                      {genreData.map((entry, index) => (
                        <ChartLegendItem key={`item-${index}`} />
                      ))}
                    </ChartLegend>
                  </ChartContainer>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="moods">
          <Card>
            <CardContent className="pt-6">
              <div className="h-[300px]">
                <ChartContainer>
                  <ChartTooltip>
                    <ChartTooltipContent />
                  </ChartTooltip>
                  <ChartGrid />
                  <ChartXAxis dataKey="month" />
                  <ChartYAxis />
                  <ChartLine
                    dataKey="energetic"
                    data={moodData}
                    stroke="hsl(var(--primary))"
                    strokeWidth={2}
                    activeDot={{ r: 6 }}
                  />
                  <ChartLine
                    dataKey="calm"
                    data={moodData}
                    stroke="hsl(var(--muted-foreground))"
                    strokeWidth={2}
                    activeDot={{ r: 6 }}
                  />
                  <ChartLine
                    dataKey="melancholic"
                    data={moodData}
                    stroke="hsl(var(--accent))"
                    strokeWidth={2}
                    activeDot={{ r: 6 }}
                  />
                  <ChartLegend />
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

