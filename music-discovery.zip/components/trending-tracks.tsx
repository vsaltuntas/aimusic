"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Play, Heart, Plus, ExternalLink, AlertCircle } from "lucide-react"
import { getTopTracks } from "@/lib/music-service"
import type { LastFmTrack } from "@/lib/lastfm-api"
import { getImageUrl } from "@/lib/music-service"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function TrendingTracks() {
  const [tracks, setTracks] = useState<LastFmTrack[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [liked, setLiked] = useState<string[]>([])

  useEffect(() => {
    const fetchTracks = async () => {
      try {
        const data = await getTopTracks(8)
        setTracks(data)
        setError(null)
      } catch (error) {
        console.error("Failed to fetch trending tracks:", error)
        setError(error.message || "Failed to load trending tracks. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    fetchTracks()
  }, [])

  const toggleLike = (trackId: string) => {
    if (liked.includes(trackId)) {
      setLiked(liked.filter((id) => id !== trackId))
    } else {
      setLiked([...liked, trackId])
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-8 w-24" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array(8)
            .fill(0)
            .map((_, i) => (
              <Card key={i}>
                <CardContent className="p-0">
                  <Skeleton className="aspect-square w-full" />
                  <div className="p-4 space-y-2">
                    <Skeleton className="h-5 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                    <div className="flex justify-between pt-2">
                      <Skeleton className="h-9 w-20" />
                      <div className="flex gap-1">
                        <Skeleton className="h-9 w-9 rounded-md" />
                        <Skeleton className="h-9 w-9 rounded-md" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Trending Tracks</h2>
        <Button variant="outline" size="sm">
          View All
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {tracks.map((track) => (
          <Card key={track.url} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="relative aspect-square">
                <Image
                  src={getImageUrl(track.image) || "/placeholder.svg"}
                  alt={track.name}
                  fill
                  className="object-cover"
                />
                <Button size="icon" className="absolute bottom-4 right-4 rounded-full">
                  <Play className="h-5 w-5" fill="currentColor" />
                </Button>
              </div>
              <div className="p-4">
                <h3 className="font-bold truncate">{track.name}</h3>
                <p className="text-sm text-muted-foreground truncate">{track.artist.name}</p>
                <div className="flex justify-between items-center mt-3">
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1"
                    onClick={() => window.open(track.url, "_blank")}
                  >
                    <ExternalLink className="h-4 w-4" /> Last.fm
                  </Button>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" onClick={() => toggleLike(track.url)}>
                      <Heart className="h-5 w-5" fill={liked.includes(track.url) ? "currentColor" : "none"} />
                    </Button>
                    <Button size="icon" variant="ghost">
                      <Plus className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

