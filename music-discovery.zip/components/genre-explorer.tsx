"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Music, Headphones, Mic, Guitar, Disc, Piano, Drumstick } from "lucide-react"

const genres = [
  {
    id: 1,
    name: "Rock",
    icon: <Guitar className="h-8 w-8" />,
    color: "bg-red-100 dark:bg-red-900/20",
    textColor: "text-red-600 dark:text-red-400",
    subgenres: ["Alternative", "Classic Rock", "Indie", "Metal", "Punk"],
  },
  {
    id: 2,
    name: "Pop",
    icon: <Music className="h-8 w-8" />,
    color: "bg-pink-100 dark:bg-pink-900/20",
    textColor: "text-pink-600 dark:text-pink-400",
    subgenres: ["Dance Pop", "Electropop", "K-Pop", "Synth-Pop", "Teen Pop"],
  },
  {
    id: 3,
    name: "Hip Hop",
    icon: <Mic className="h-8 w-8" />,
    color: "bg-purple-100 dark:bg-purple-900/20",
    textColor: "text-purple-600 dark:text-purple-400",
    subgenres: ["Trap", "Rap", "Drill", "Boom Bap", "Conscious"],
  },
  {
    id: 4,
    name: "Electronic",
    icon: <Headphones className="h-8 w-8" />,
    color: "bg-blue-100 dark:bg-blue-900/20",
    textColor: "text-blue-600 dark:text-blue-400",
    subgenres: ["House", "Techno", "Dubstep", "Trance", "EDM"],
  },
  {
    id: 5,
    name: "Jazz",
    icon: <Piano className="h-8 w-8" />,
    color: "bg-amber-100 dark:bg-amber-900/20",
    textColor: "text-amber-600 dark:text-amber-400",
    subgenres: ["Bebop", "Fusion", "Smooth", "Modal", "Free"],
  },
  {
    id: 6,
    name: "Classical",
    icon: <Piano className="h-8 w-8" />,
    color: "bg-emerald-100 dark:bg-emerald-900/20",
    textColor: "text-emerald-600 dark:text-emerald-400",
    subgenres: ["Baroque", "Romantic", "Contemporary", "Opera", "Symphony"],
  },
  {
    id: 7,
    name: "R&B",
    icon: <Disc className="h-8 w-8" />,
    color: "bg-indigo-100 dark:bg-indigo-900/20",
    textColor: "text-indigo-600 dark:text-indigo-400",
    subgenres: ["Soul", "Contemporary", "Neo Soul", "Funk", "Motown"],
  },
  {
    id: 8,
    name: "Reggae",
    icon: <Drumstick className="h-8 w-8" />,
    color: "bg-green-100 dark:bg-green-900/20",
    textColor: "text-green-600 dark:text-green-400",
    subgenres: ["Dancehall", "Dub", "Roots", "Ska", "Rocksteady"],
  },
]

export default function GenreExplorer() {
  const [selectedGenre, setSelectedGenre] = useState<number | null>(null)

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold">Explore by Genre</h2>
      <p className="text-muted-foreground">Discover new music by exploring different genres and their unique sounds.</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {genres.map((genre) => (
          <Card
            key={genre.id}
            className={`genre-card cursor-pointer ${selectedGenre === genre.id ? "ring-2 ring-primary" : ""}`}
            onClick={() => setSelectedGenre(genre.id)}
          >
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className={`p-4 rounded-full ${genre.color} ${genre.textColor} mb-4`}>{genre.icon}</div>
              <h3 className="font-semibold text-lg">{genre.name}</h3>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedGenre && (
        <div className="mt-8">
          <h3 className="text-xl font-semibold mb-4">{genres.find((g) => g.id === selectedGenre)?.name} Subgenres</h3>
          <div className="flex flex-wrap gap-2">
            {genres
              .find((g) => g.id === selectedGenre)
              ?.subgenres.map((subgenre, i) => (
                <Badge key={i} variant="secondary" className="text-sm py-1 px-3">
                  {subgenre}
                </Badge>
              ))}
          </div>
        </div>
      )}
    </div>
  )
}

