"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"
import { ModeToggle } from "@/components/mode-toggle"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useUser } from "@/context/user-context"
import { Music, Headphones, Radio, Mic, Library, Heart, Tag, Search } from "lucide-react"

export default function Header() {
  const { user } = useUser()

  return (
    <header className="border-b">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center gap-2">
            <Music className="h-6 w-6 text-primary" />
            <span className="font-bold text-xl">Melodic AI</span>
          </Link>

          <NavigationMenu className="hidden md:flex">
            <NavigationMenuList>
              <NavigationMenuItem>
                <NavigationMenuTrigger>Explore</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <div className="grid grid-cols-2 gap-3 p-4 w-[400px]">
                    <Link href="/genres" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                      <Headphones className="h-5 w-5" />
                      <div>
                        <div className="font-medium">Genres</div>
                        <div className="text-sm text-muted-foreground">Explore music by genre</div>
                      </div>
                    </Link>
                    <Link href="/new-releases" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                      <Music className="h-5 w-5" />
                      <div>
                        <div className="font-medium">New Releases</div>
                        <div className="text-sm text-muted-foreground">The latest music</div>
                      </div>
                    </Link>
                    <Link href="/artists" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                      <Mic className="h-5 w-5" />
                      <div>
                        <div className="font-medium">Artists</div>
                        <div className="text-sm text-muted-foreground">Find your favorite artists</div>
                      </div>
                    </Link>
                    <Link href="/radio" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                      <Radio className="h-5 w-5" />
                      <div>
                        <div className="font-medium">Radio</div>
                        <div className="text-sm text-muted-foreground">AI-curated stations</div>
                      </div>
                    </Link>
                  </div>
                </NavigationMenuContent>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/library" legacyBehavior passHref>
                  <NavigationMenuLink className="flex items-center gap-1 px-4 py-2">
                    <Library className="h-4 w-4" />
                    <span>Library</span>
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/favorites" legacyBehavior passHref>
                  <NavigationMenuLink className="flex items-center gap-1 px-4 py-2">
                    <Heart className="h-4 w-4" />
                    <span>Favorites</span>
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/ai-music-tagging" legacyBehavior passHref>
                  <NavigationMenuLink className="flex items-center gap-1 px-4 py-2">
                    <Tag className="h-4 w-4" />
                    <span>AI Tagging</span>
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/ai-songwriting" legacyBehavior passHref>
                  <NavigationMenuLink className="flex items-center gap-1 px-4 py-2">
                    <Music className="h-4 w-4" />
                    <span>AI Songwriting</span>
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative hidden md:block w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input type="search" placeholder="Search music..." className="pl-8 w-full" />
          </div>
          <ModeToggle />
          {user ? (
            <Avatar>
              <AvatarImage src={user.image} alt={user.name} />
              <AvatarFallback>{user.name.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
          ) : (
            <Button asChild variant="outline" size="sm">
              <Link href="/login">Login</Link>
            </Button>
          )}
        </div>
      </div>
    </header>
  )
}

