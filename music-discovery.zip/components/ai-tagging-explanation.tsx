import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface AITaggingExplanationProps {
  className?: string
}

export default function AITaggingExplanation({ className }: AITaggingExplanationProps) {
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>How Our AI Music Tagging System Works</CardTitle>
        <CardDescription>Our system uses a comprehensive approach to analyze and categorize music.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">1. Identify Primary Genre and Subgenres</h3>
            <p>We determine the main genre and any notable subgenres or genre blends.</p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">2. Determine Tempo and Rhythmic Structure</h3>
            <p>We analyze the song's energy, movement, and rhythmic patterns.</p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">3. Identify Instrumentation and Production Style</h3>
            <p>We examine the instruments used and the overall production approach.</p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">4. Analyze Vocal Style and Techniques</h3>
            <p>We consider the vocal performance and any notable techniques used.</p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">5. Determine Lyrical Themes and Emotional Tone</h3>
            <p>We assess the song's lyrical content and the emotions it conveys.</p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">6. Consider Cultural and Historical Context</h3>
            <p>We take into account any significant cultural or historical influences.</p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">7. Evaluate Usage Context and Listening Experience</h3>
            <p>We consider how and where the music is best enjoyed.</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

