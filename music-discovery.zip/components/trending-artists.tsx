"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Plus, ExternalLink } from "lucide-react"
import { getTopArtists } from "@/lib/music-service"
import type { LastFmArtist } from "@/lib/lastfm-api"
import { getImageUrl } from "@/lib/music-service"

export default function TrendingArtists() {
  const [artists, setArtists] = useState<LastFmArtist[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchArtists = async () => {
      try {
        const data = await getTopArtists(8)
        setArtists(data)
        setError(null)
      } catch (error) {
        console.error("Failed to fetch trending artists:", error)
        setError(error.message || "Failed to load trending artists. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    fetchArtists()
  }, [])

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-8 w-24" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array(8)
            .fill(0)
            .map((_, i) => (
              <Card key={i}>
                <CardContent className="p-0">
                  <Skeleton className="aspect-square w-full" />
                  <div className="p-4 space-y-2">
                    <Skeleton className="h-5 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                    <div className="flex justify-between pt-2">
                      <Skeleton className="h-9 w-20" />
                      <Skeleton className="h-9 w-9 rounded-md" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Trending Artists</h2>
        <Button variant="outline" size="sm">
          View All
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {artists.map((artist) => (
          <Card key={artist.url} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="relative aspect-square">
                <Image
                  src={getImageUrl(artist.image) || "/placeholder.svg"}
                  alt={artist.name}
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex flex-col justify-end p-4">
                  <h3 className="text-lg font-bold text-white">{artist.name}</h3>
                  <p className="text-sm text-white/80">{Number(artist.listeners).toLocaleString()} listeners</p>
                </div>
              </div>
              <div className="p-4 flex justify-between items-center">
                <Button variant="outline" size="sm" className="gap-1" onClick={() => window.open(artist.url, "_blank")}>
                  <ExternalLink className="h-4 w-4" /> Last.fm
                </Button>
                <Button size="icon" variant="ghost">
                  <Plus className="h-5 w-5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

