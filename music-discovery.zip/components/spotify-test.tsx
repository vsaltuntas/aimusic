"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function SpotifyTest() {
  const [result, setResult] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  async function testSpotify() {
    setIsLoading(true)
    try {
      const response = await fetch("/api/spotify/test")
      const data = await response.json()
      setResult(JSON.stringify(data, null, 2))
    } catch (error) {
      setResult("Hata oluştu: " + JSON.stringify(error, null, 2))
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <Button onClick={testSpotify} disabled={isLoading}>
        {isLoading ? "Test ediliyor..." : "Spotify Bağlantısını Test Et"}
      </Button>
      {result && (
        <Alert>
          <AlertTitle>Test Sonucu</AlertTitle>
          <AlertDescription>
            <pre>{result}</pre>
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}

