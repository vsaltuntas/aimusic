"use client"

import { useState } from "react"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Play, SkipForward, SkipBack, Heart, Plus, Volume2, Shuffle, Repeat } from "lucide-react"
import { Badge } from "@/components/ui/badge"

// Mock data for recommended tracks
const recommendedTracks = [
  {
    id: 1,
    title: "Midnight Serenade",
    artist: "Luna Eclipse",
    album: "Nocturnal Whispers",
    duration: "3:45",
    image: "/placeholder.svg?height=300&width=300",
    genres: ["Electronic", "Ambient"],
    match: 98,
  },
  {
    id: 2,
    title: "Cosmic Drift",
    artist: "Stellar Waves",
    album: "Interstellar Journey",
    duration: "4:12",
    image: "/placeholder.svg?height=300&width=300",
    genres: ["Synth-Pop", "Space Music"],
    match: 95,
  },
  {
    id: 3,
    title: "Urban Echoes",
    artist: "City Pulse",
    album: "Metropolitan",
    duration: "3:28",
    image: "/placeholder.svg?height=300&width=300",
    genres: ["Hip Hop", "Electronic"],
    match: 92,
  },
  {
    id: 4,
    title: "Velvet Dreams",
    artist: "Midnight Muse",
    album: "Ethereal Visions",
    duration: "5:03",
    image: "/placeholder.svg?height=300&width=300",
    genres: ["Dream Pop", "Indie"],
    match: 90,
  },
]

export default function RecommendedTracks() {
  const [currentTrack, setCurrentTrack] = useState(recommendedTracks[0])
  const [isPlaying, setIsPlaying] = useState(false)
  const [liked, setLiked] = useState<number[]>([])

  const togglePlay = () => setIsPlaying(!isPlaying)

  const toggleLike = (id: number) => {
    if (liked.includes(id)) {
      setLiked(liked.filter((trackId) => trackId !== id))
    } else {
      setLiked([...liked, id])
    }
  }

  const playTrack = (track: (typeof recommendedTracks)[0]) => {
    setCurrentTrack(track)
    setIsPlaying(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-1/2 space-y-4">
          <h2 className="text-3xl font-bold">Recommended For You</h2>
          <p className="text-muted-foreground">
            Based on your listening history, our AI thinks you'll love these tracks.
          </p>

          <div className="space-y-3">
            {recommendedTracks.map((track) => (
              <Card key={track.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex items-center p-3">
                    <div className="relative h-12 w-12 mr-3 flex-shrink-0">
                      <Image
                        src={track.image || "/placeholder.svg"}
                        alt={track.album}
                        fill
                        className="object-cover rounded-md"
                      />
                      <Button
                        size="icon"
                        variant="ghost"
                        className="absolute inset-0 bg-black/30 opacity-0 hover:opacity-100 rounded-md"
                        onClick={() => playTrack(track)}
                      >
                        <Play className="h-6 w-6 text-white" fill="white" />
                      </Button>
                    </div>
                    <div className="flex-grow min-w-0">
                      <div className="flex items-center justify-between">
                        <div className="truncate">
                          <div className="font-medium truncate">{track.title}</div>
                          <div className="text-sm text-muted-foreground truncate">
                            {track.artist} • {track.album}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 ml-2 flex-shrink-0">
                          <Badge variant="outline" className="bg-primary/10">
                            {track.match}% Match
                          </Badge>
                          <Button size="icon" variant="ghost" onClick={() => toggleLike(track.id)}>
                            <Heart className="h-5 w-5" fill={liked.includes(track.id) ? "currentColor" : "none"} />
                          </Button>
                          <Button size="icon" variant="ghost">
                            <Plus className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="md:w-1/2">
          <Card className="h-full">
            <CardContent className="p-6 flex flex-col h-full">
              <div className="text-center mb-6">
                <h3 className="text-xl font-semibold mb-1">Now Playing</h3>
                <p className="text-muted-foreground">From your personalized recommendations</p>
              </div>

              <div className="flex-grow flex flex-col items-center justify-center">
                <div className="relative w-48 h-48 mb-6">
                  <Image
                    src={currentTrack.image || "/placeholder.svg"}
                    alt={currentTrack.album}
                    fill
                    className="object-cover rounded-lg shadow-lg"
                  />
                </div>

                <div className="text-center mb-6 w-full">
                  <h3 className="text-xl font-bold mb-1">{currentTrack.title}</h3>
                  <p className="text-muted-foreground">{currentTrack.artist}</p>
                  <div className="flex justify-center gap-2 mt-2">
                    {currentTrack.genres.map((genre, i) => (
                      <Badge key={i} variant="secondary" className="text-xs">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="w-full mb-6">
                  <Slider defaultValue={[33]} max={100} step={1} className="mb-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>1:15</span>
                    <span>{currentTrack.duration}</span>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-4 mb-6">
                  <Button size="icon" variant="ghost">
                    <Shuffle className="h-5 w-5" />
                  </Button>
                  <Button size="icon" variant="outline">
                    <SkipBack className="h-5 w-5" />
                  </Button>
                  <Button size="icon" className="h-12 w-12" onClick={togglePlay}>
                    {isPlaying ? (
                      <span className="h-5 w-5 block bg-white rounded-sm"></span>
                    ) : (
                      <Play className="h-5 w-5" fill="currentColor" />
                    )}
                  </Button>
                  <Button size="icon" variant="outline">
                    <SkipForward className="h-5 w-5" />
                  </Button>
                  <Button size="icon" variant="ghost">
                    <Repeat className="h-5 w-5" />
                  </Button>
                </div>

                <div className="flex items-center gap-2 w-full max-w-xs">
                  <Volume2 className="h-4 w-4 text-muted-foreground" />
                  <Slider defaultValue={[70]} max={100} step={1} />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

