import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export type MusicRecommendation = {
  title: string
  artist: string
  album: string
  genres: string[]
  year: number
  matchScore: number
  reason: string
}

export type ArtistRecommendation = {
  name: string
  genres: string[]
  similarTo: string[]
  topTracks: string[]
  description: string
  matchScore: number
}

export type PlaylistRecommendation = {
  name: string
  description: string
  tracks: number
  duration: string
  mood: string[]
}

export type SongIdea = {
  title: string
  lyrics: string
  genre: string
  mood: string
  tempo: string
  key: string
  structure: string
}

export async function generateMusicRecommendations(
  userPreferences: string,
  userHistory: string[] = [],
): Promise<MusicRecommendation[]> {
  const prompt = `
    Based on the following user preferences and listening history, recommend 5 songs that the user might enjoy.
    
    User preferences: ${userPreferences}
    
    User listening history: ${userHistory.join(", ")}
    
    For each recommendation, provide:
    - Song title
    - Artist name
    - Album name
    - Genres (list)
    - Release year
    - Match score (0-100)
    - Reason for recommendation
    
    Format the response as a JSON array.
  `

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
    })

    return JSON.parse(text) as MusicRecommendation[]
  } catch (error) {
    console.error("Error generating music recommendations:", error)
    return []
  }
}

export async function generateSongIdea(
  prompt: string,
  genre?: string,
  mood?: string,
  structure?: string,
): Promise<SongIdea | null> {
  const systemPrompt = `
    You are a professional songwriter with expertise in multiple genres. 
    Create an original song based on the user's prompt and preferences.
    Include title, lyrics, genre, mood, tempo, key, and structure.
    Make the lyrics creative, meaningful, and appropriate for the requested genre and mood.
  `

  const userPrompt = `
    Create a song with the following details:
    
    Concept: ${prompt}
    ${genre ? `Genre: ${genre}` : ""}
    ${mood ? `Mood: ${mood}` : ""}
    ${structure ? `Structure: ${structure}` : ""}
    
    Format the response as a JSON object with the following properties:
    - title
    - lyrics (include verse, chorus, bridge sections)
    - genre
    - mood
    - tempo
    - key
    - structure
  `

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: userPrompt,
    })

    return JSON.parse(text) as SongIdea
  } catch (error) {
    console.error("Error generating song idea:", error)
    return null
  }
}

