import SpotifyWebApi from "spotify-web-api-node"
import { supabase } from "./supabase-client"

const spotifyApi = new SpotifyWebApi({
  clientId: process.env.SPOTIFY_CLIENT_ID,
  clientSecret: process.env.SPOTIFY_CLIENT_SECRET,
  redirectUri: process.env.SPOTIFY_REDIRECT_URI,
})

// Örnek veriler
const mockNewReleases = [
  { id: "1", name: "Yeni Albüm 1", images: [{ url: "/placeholder.svg" }] },
  { id: "2", name: "Yeni Albüm 2", images: [{ url: "/placeholder.svg" }] },
  { id: "3", name: "Yeni Albüm 3", images: [{ url: "/placeholder.svg" }] },
]

const mockFeaturedPlaylists = [
  { id: "1", name: "Çalma Listesi 1", images: [{ url: "/placeholder.svg" }] },
  { id: "2", name: "Çalma Listesi 2", images: [{ url: "/placeholder.svg" }] },
  { id: "3", name: "Çalma Listesi 3", images: [{ url: "/placeholder.svg" }] },
]

export async function getNewReleases() {
  // Spotify API yerine mock veri dönüyoruz
  return mockNewReleases
}

export async function getFeaturedPlaylists() {
  // Spotify API yerine mock veri dönüyoruz
  return mockFeaturedPlaylists
}

export async function getSpotifyAuthUrl() {
  const scopes = ["user-read-private", "user-read-email", "user-top-read", "user-library-read"]
  return spotifyApi.createAuthorizeURL(scopes, "state")
}

export async function handleSpotifyCallback(code: string) {
  const data = await spotifyApi.authorizationCodeGrant(code)
  spotifyApi.setAccessToken(data.body["access_token"])
  spotifyApi.setRefreshToken(data.body["refresh_token"])
  return data.body
}

export async function getUserProfile() {
  const data = await spotifyApi.getMe()
  return data.body
}

export async function saveSpotifyUser(
  spotifyProfile: SpotifyApi.CurrentUsersProfileResponse,
  tokens: {
    access_token: string
    refresh_token: string
    expires_in: number
  },
) {
  const { id, display_name, email, images } = spotifyProfile

  const { data: existingUser, error: fetchError } = await supabase
    .from("users")
    .select("*")
    .eq("spotify_id", id)
    .single()

  if (fetchError && fetchError.code !== "PGRST116") {
    throw fetchError
  }

  if (existingUser) {
    // Update existing user
    const { data, error } = await supabase
      .from("users")
      .update({
        name: display_name,
        email,
        image_url: images?.[0]?.url,
        updated_at: new Date().toISOString(),
      })
      .eq("id", existingUser.id)
      .single()

    if (error) throw error
    return data
  } else {
    // Create new user
    const { data, error } = await supabase
      .from("users")
      .insert({
        spotify_id: id,
        name: display_name,
        email,
        image_url: images?.[0]?.url,
      })
      .single()

    if (error) throw error
    return data
  }
}

async function getAccessToken() {
  const data = await spotifyApi.clientCredentialsGrant()
  spotifyApi.setAccessToken(data.body["access_token"])
}

export async function getArtistTopTracks(artistId: string) {
  await getAccessToken()
  const data = await spotifyApi.getArtistTopTracks(artistId, "US")
  return data.body.tracks
}

export async function searchTracks(query: string) {
  await getAccessToken()
  const data = await spotifyApi.searchTracks(query, { limit: 20 })
  return data.body.tracks?.items
}

export async function testSpotifyConnection() {
  try {
    await getAccessToken()
    const data = await spotifyApi.getAvailableGenreSeeds()
    console.log("Spotify bağlantısı başarılı:", data.body)
    return { success: true, message: "Spotify bağlantısı başarılı" }
  } catch (error) {
    console.error("Spotify bağlantı hatası:", error)
    return { success: false, message: "Spotify bağlantısı başarısız", error }
  }
}

