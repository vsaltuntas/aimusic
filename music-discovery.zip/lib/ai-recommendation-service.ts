import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import type { LastFmTrack } from "./lastfm-api"
import { getUserPreferences } from "./db-service"

export type AIRecommendation = {
  tracks: {
    name: string
    artist: string
    reason: string
    matchScore: number
  }[]
  artists: {
    name: string
    reason: string
    matchScore: number
  }[]
  genres: {
    name: string
    reason: string
    matchScore: number
  }[]
  playlist: {
    name: string
    description: string
    mood: string[]
  }
}

export async function generateRecommendations(
  userId: string,
  prompt = "",
  recentTracks: LastFmTrack[] = [],
  energyLevel = 50,
  experimentalLevel = 50,
): Promise<AIRecommendation> {
  // Get user preferences from database
  const userPrefs = await getUserPreferences(userId)

  // Format user preferences for the AI
  const userPreferences = {
    favoriteGenres: userPrefs?.favoriteGenres || [],
    favoriteArtists: userPrefs?.favoriteArtists || [],
    dislikedGenres: userPrefs?.dislikedGenres || [],
    dislikedArtists: userPrefs?.dislikedArtists || [],
  }

  // Format recent tracks for the AI
  const recentTracksFormatted = recentTracks.map((track) => ({
    name: track.name,
    artist: track.artist.name,
  }))

  // Create the system prompt
  const systemPrompt = `
    You are an expert music recommendation AI with deep knowledge of music genres, artists, and songs.
    Your task is to provide personalized music recommendations based on the user's preferences, listening history, and specific request.
    
    Consider the following factors:
    - The user's favorite genres and artists
    - The user's disliked genres and artists
    - The user's recent listening history
    - The user's specific request or mood
    - The energy level preference (0-100, where 0 is calm and 100 is energetic)
    - The experimental level preference (0-100, where 0 is mainstream and 100 is experimental)
    
    Provide recommendations in the following categories:
    1. Tracks: Recommend 5 specific songs that match the user's taste and request
    2. Artists: Recommend 3 artists that the user might enjoy
    3. Genres: Recommend 3 genres or subgenres that the user might want to explore
    4. Playlist: Suggest a playlist concept with a name, description, and mood tags
    
    For each recommendation, provide a brief explanation of why you're recommending it and a match score (0-100) indicating how well it matches the user's preferences.
  `

  // Create the user prompt
  const userPrompt = `
    User preferences:
    - Favorite genres: ${userPreferences.favoriteGenres.join(", ") || "None specified"}
    - Favorite artists: ${userPreferences.favoriteArtists.join(", ") || "None specified"}
    - Disliked genres: ${userPreferences.dislikedGenres.join(", ") || "None specified"}
    - Disliked artists: ${userPreferences.dislikedArtists.join(", ") || "None specified"}
    
    Recent listening history:
    ${
      recentTracksFormatted.length > 0
        ? recentTracksFormatted.map((t) => `- "${t.name}" by ${t.artist}`).join("\n")
        : "No recent tracks available"
    }
    
    Energy level preference: ${energyLevel}/100
    Experimental level preference: ${experimentalLevel}/100
    
    User request: ${prompt || "General recommendations based on my taste"}
    
    Please provide your recommendations in JSON format with the following structure:
    {
      "tracks": [
        {
          "name": "Song Name",
          "artist": "Artist Name",
          "reason": "Brief explanation",
          "matchScore": 85
        }
      ],
      "artists": [
        {
          "name": "Artist Name",
          "reason": "Brief explanation",
          "matchScore": 90
        }
      ],
      "genres": [
        {
          "name": "Genre Name",
          "reason": "Brief explanation",
          "matchScore": 80
        }
      ],
      "playlist": {
        "name": "Playlist Name",
        "description": "Brief description",
        "mood": ["mood1", "mood2", "mood3"]
      }
    }
  `

  try {
    // Generate recommendations using the AI SDK
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: userPrompt,
    })

    // Parse the JSON response
    return JSON.parse(text) as AIRecommendation
  } catch (error) {
    console.error("Error generating AI recommendations:", error)

    // Return fallback recommendations if the AI fails
    return {
      tracks: [
        {
          name: "Fallback Song 1",
          artist: "Fallback Artist",
          reason: "This is a fallback recommendation due to an error.",
          matchScore: 50,
        },
        {
          name: "Fallback Song 2",
          artist: "Fallback Artist",
          reason: "This is a fallback recommendation due to an error.",
          matchScore: 50,
        },
      ],
      artists: [
        {
          name: "Fallback Artist",
          reason: "This is a fallback recommendation due to an error.",
          matchScore: 50,
        },
      ],
      genres: [
        {
          name: "Fallback Genre",
          reason: "This is a fallback recommendation due to an error.",
          matchScore: 50,
        },
      ],
      playlist: {
        name: "Fallback Playlist",
        description: "This is a fallback playlist due to an error.",
        mood: ["neutral"],
      },
    }
  }
}

export async function generateSongIdea(
  prompt: string,
  genre?: string,
  mood?: string,
  structure?: string,
): Promise<{
  title: string
  lyrics: string
  genre: string
  mood: string
  tempo: string
  key: string
  structure: string
} | null> {
  const systemPrompt = `
    You are a professional songwriter with expertise in multiple genres. 
    Create an original song based on the user's prompt and preferences.
    Include title, lyrics, genre, mood, tempo, key, and structure.
    Make the lyrics creative, meaningful, and appropriate for the requested genre and mood.
  `

  const userPrompt = `
    Create a song with the following details:
    
    Concept: ${prompt}
    ${genre ? `Genre: ${genre}` : ""}
    ${mood ? `Mood: ${mood}` : ""}
    ${structure ? `Structure: ${structure}` : ""}
    
    Format the response as a JSON object with the following properties:
    - title
    - lyrics (include verse, chorus, bridge sections)
    - genre
    - mood
    - tempo
    - key
    - structure
  `

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: userPrompt,
    })

    return JSON.parse(text) as {
      title: string
      lyrics: string
      genre: string
      mood: string
      tempo: string
      key: string
      structure: string
    }
  } catch (error) {
    console.error("Error generating song idea:", error)
    return null
  }
}

