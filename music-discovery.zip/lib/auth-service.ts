import { createClient } from "@supabase/supabase-js"
import type { User } from "./db-service"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  console.error("Supabase environment variables are missing")
}

export const supabase = createClient(supabaseUrl!, supabaseAnonKey!)

export async function getCurrentUser(): Promise<User | null> {
  try {
    const { data: sessionData, error: sessionError } = await supabase.auth.getSession()

    if (sessionError) {
      console.error("Error getting auth session:", sessionError)
      return null
    }

    if (!sessionData.session) {
      console.log("No active session found")
      return null
    }

    const { data: userData, error: userError } = await supabase.auth.getUser()

    if (userError) {
      console.error("Error getting user data:", userError)
      return null
    }

    if (userData.user) {
      return {
        id: userData.user.id,
        email: userData.user.email || "",
        name: userData.user.user_metadata.name || "",
        image: userData.user.user_metadata.avatar_url,
        createdAt: new Date(userData.user.created_at),
      }
    }

    return null
  } catch (error) {
    console.error("Error getting current user:", error)
    return null
  }
}

export async function signIn(email: string, password: string): Promise<User | null> {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      throw new Error(error.message)
    }

    if (data.user) {
      return {
        id: data.user.id,
        email: data.user.email || "",
        name: data.user.user_metadata.name || "",
        image: data.user.user_metadata.avatar_url,
        createdAt: new Date(data.user.created_at),
      }
    }

    return null
  } catch (error: any) {
    console.error("Error signing in:", error)
    throw new Error(error.message || "Failed to sign in")
  }
}

export async function signOut(): Promise<void> {
  try {
    const { error } = await supabase.auth.signOut()

    if (error) {
      throw new Error(error.message)
    }
  } catch (error: any) {
    console.error("Error signing out:", error)
    throw new Error(error.message || "Failed to sign out")
  }
}

export async function signUp(
  email: string,
  password: string,
  name: string,
): Promise<{ id: string; email: string; name: string; image?: string; createdAt: Date } | null> {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name,
        },
      },
    })

    if (error) {
      throw new Error(error.message)
    }

    if (data.user) {
      return {
        id: data.user.id,
        email: data.user.email || "",
        name: data.user.user_metadata.name || "",
        image: data.user.user_metadata.avatar_url,
        createdAt: new Date(data.user.created_at),
      }
    }

    return null
  } catch (error: any) {
    console.error("Error signing up:", error)
    throw new Error(error.message || "Failed to sign up")
  }
}

