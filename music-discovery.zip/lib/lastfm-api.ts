const LASTFM_API_KEY = process.env.LASTFM_API_KEY || ""
const LASTFM_API_URL = "https://ws.audioscrobbler.com/2.0/"

export type LastFmArtist = {
  name: string
  mbid: string
  url: string
  image: {
    "#text": string
    size: string
  }[]
  listeners: string
  playcount: string
}

export type LastFmTrack = {
  name: string
  artist: {
    name: string
    mbid: string
  }
  url: string
  listeners: string
  image: {
    "#text": string
    size: string
  }[]
}

export type LastFmTag = {
  name: string
  url: string
  reach: string
  taggings: string
}

async function lastFmFetch<T>(method: string, params: Record<string, string> = {}): Promise<T> {
  const queryParams = new URLSearchParams({
    method,
    api_key: LASTFM_API_KEY,
    format: "json",
    ...params,
  })

  const response = await fetch(`${LASTFM_API_URL}?${queryParams.toString()}`)

  if (!response.ok) {
    const errorBody = await response.text()
    throw new Error(`Last.fm API error: ${response.status} ${response.statusText}\nBody: ${errorBody}`)
  }

  const data = await response.json()

  if (data.error) {
    throw new Error(`Last.fm API error: ${data.error} ${data.message}`)
  }

  return data
}

export async function getTopArtists(limit = 10, page = 1): Promise<LastFmArtist[]> {
  const response = await lastFmFetch<{ artists: { artist: LastFmArtist[] } }>("chart.getTopArtists", {
    limit: limit.toString(),
    page: page.toString(),
  })

  return response.artists.artist
}

export async function getTopTracks(limit = 10, page = 1): Promise<LastFmTrack[]> {
  const response = await lastFmFetch<{ tracks: { track: LastFmTrack[] } }>("chart.getTopTracks", {
    limit: limit.toString(),
    page: page.toString(),
  })

  return response.tracks.track
}

export async function getTracksByTag(tag: string, limit = 10, page = 1): Promise<LastFmTrack[]> {
  const response = await lastFmFetch<{ tracks: { track: LastFmTrack[] } }>("tag.getTopTracks", {
    tag,
    limit: limit.toString(),
    page: page.toString(),
  })

  return response.tracks.track
}

export async function getTopTags(limit = 50): Promise<LastFmTag[]> {
  const response = await lastFmFetch<{ toptags: { tag: LastFmTag[] } }>("tag.getTopTags")

  return response.toptags.tag
    .filter((tag) => tag.name !== "seen live") // Filter out non-genre tags
    .slice(0, limit)
}

export async function searchArtists(query: string, limit = 10, page = 1): Promise<LastFmArtist[]> {
  const response = await lastFmFetch<{ results: { artistmatches: { artist: LastFmArtist[] } } }>("artist.search", {
    artist: query,
    limit: limit.toString(),
    page: page.toString(),
  })

  return response.results.artistmatches.artist
}

export async function searchTracks(query: string, limit = 10, page = 1): Promise<LastFmTrack[]> {
  const response = await lastFmFetch<{ results: { trackmatches: { track: LastFmTrack[] } } }>("track.search", {
    track: query,
    limit: limit.toString(),
    page: page.toString(),
  })

  return response.results.trackmatches.track
}

