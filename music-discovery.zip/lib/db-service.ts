import { getSupabase } from "./supabase-client"

export type User = {
  id: string
  name: string
  email: string
  image?: string
  createdAt: Date
}

export type Song = {
  id: string
  title: string
  artist: string
  album: string
  genres: string[]
  year: number
  duration: number
  imageUrl: string
}

export type Artist = {
  id: string
  name: string
  genres: string[]
  imageUrl: string
  popularity: number
}

export type UserPreference = {
  userId: string
  favoriteGenres: string[]
  favoriteArtists: string[]
  dislikedGenres: string[]
  dislikedArtists: string[]
  listeningHistory: {
    songId: string
    timestamp: Date
    duration: number
  }[]
}

// User functions
export async function getUserById(id: string): Promise<User | null> {
  try {
    const supabase = getSupabase()
    const { data, error } = await supabase.from("users").select("*").eq("id", id).single()

    if (error) {
      throw error
    }

    if (data) {
      return {
        id: data.id,
        name: data.name,
        email: data.email,
        image: data.image_url,
        createdAt: new Date(data.created_at),
      }
    }

    return null
  } catch (error) {
    console.error("Error getting user by ID:", error)
    return null
  }
}

export async function createUser(user: User): Promise<User | null> {
  try {
    const supabase = getSupabase()
    const { data, error } = await supabase
      .from("users")
      .insert([
        {
          id: user.id,
          name: user.name,
          email: user.email,
          image_url: user.image,
        },
      ])
      .select()
      .single()

    if (error) {
      throw error
    }

    if (data) {
      return {
        id: data.id,
        name: data.name,
        email: data.email,
        image: data.image_url,
        createdAt: new Date(data.created_at),
      }
    }

    return null
  } catch (error) {
    console.error("Error creating user:", error)
    return null
  }
}

// User preferences functions
export async function getUserPreferences(userId: string): Promise<UserPreference | null> {
  try {
    const supabase = getSupabase()
    // Get user preferences
    const { data: prefsData, error: prefsError } = await supabase
      .from("user_preferences")
      .select("*")
      .eq("user_id", userId)
      .single()

    if (prefsError && prefsError.code !== "PGRST116") {
      throw prefsError
    }

    // Get listening history
    const { data: historyData, error: historyError } = await supabase
      .from("listening_history")
      .select("*")
      .eq("user_id", userId)
      .order("timestamp", { ascending: false })
      .limit(50)

    if (historyError) {
      throw historyError
    }

    if (!prefsData) {
      // If no preferences exist, create default preferences
      return {
        userId,
        favoriteGenres: [],
        favoriteArtists: [],
        dislikedGenres: [],
        dislikedArtists: [],
        listeningHistory: historyData
          ? historyData.map((item) => ({
              songId: item.song_id,
              timestamp: new Date(item.timestamp),
              duration: item.duration,
            }))
          : [],
      }
    }

    return {
      userId,
      favoriteGenres: prefsData.favorite_genres || [],
      favoriteArtists: prefsData.favorite_artists || [],
      dislikedGenres: prefsData.disliked_genres || [],
      dislikedArtists: prefsData.disliked_artists || [],
      listeningHistory: historyData
        ? historyData.map((item) => ({
            songId: item.song_id,
            timestamp: new Date(item.timestamp),
            duration: item.duration,
          }))
        : [],
    }
  } catch (error) {
    console.error("Error getting user preferences:", error)
    return null
  }
}

export async function updateUserPreferences(userId: string, preferences: Partial<UserPreference>): Promise<boolean> {
  try {
    const supabase = getSupabase()
    const { error } = await supabase.from("user_preferences").upsert(
      {
        user_id: userId,
        favorite_genres: preferences.favoriteGenres,
        favorite_artists: preferences.favoriteArtists,
        disliked_genres: preferences.dislikedGenres,
        disliked_artists: preferences.dislikedArtists,
      },
      { onConflict: "user_id" },
    )

    if (error) {
      throw error
    }

    return true
  } catch (error) {
    console.error("Error updating user preferences:", error)
    return false
  }
}

// Favorites functions
export async function addSongToFavorites(userId: string, songId: string): Promise<boolean> {
  try {
    const supabase = getSupabase()
    const { error } = await supabase.from("favorites").insert([
      {
        user_id: userId,
        song_id: songId,
        type: "song",
      },
    ])

    if (error) {
      throw error
    }

    return true
  } catch (error) {
    console.error("Error adding song to favorites:", error)
    return false
  }
}

export async function removeSongFromFavorites(userId: string, songId: string): Promise<boolean> {
  try {
    const supabase = getSupabase()
    const { error } = await supabase
      .from("favorites")
      .delete()
      .eq("user_id", userId)
      .eq("song_id", songId)
      .eq("type", "song")

    if (error) {
      throw error
    }

    return true
  } catch (error) {
    console.error("Error removing song from favorites:", error)
    return false
  }
}

export async function addArtistToFavorites(userId: string, artistId: string): Promise<boolean> {
  try {
    const supabase = getSupabase()
    const { error } = await supabase.from("favorites").insert([
      {
        user_id: userId,
        artist_id: artistId,
        type: "artist",
      },
    ])

    if (error) {
      throw error
    }

    return true
  } catch (error) {
    console.error("Error adding artist to favorites:", error)
    return false
  }
}

export async function removeArtistFromFavorites(userId: string, artistId: string): Promise<boolean> {
  try {
    const supabase = getSupabase()
    const { error } = await supabase
      .from("favorites")
      .delete()
      .eq("user_id", userId)
      .eq("artist_id", artistId)
      .eq("type", "artist")

    if (error) {
      throw error
    }

    return true
  } catch (error) {
    console.error("Error removing artist from favorites:", error)
    return false
  }
}

// Listening history functions
export async function recordSongPlay(userId: string, songId: string, duration: number): Promise<boolean> {
  try {
    const supabase = getSupabase()
    const { error } = await supabase.from("listening_history").insert([
      {
        user_id: userId,
        song_id: songId,
        duration,
        timestamp: new Date().toISOString(),
      },
    ])

    if (error) {
      throw error
    }

    return true
  } catch (error) {
    console.error("Error recording song play:", error)
    return false
  }
}

// Get user's favorite songs
export async function getUserFavoriteSongs(userId: string): Promise<string[]> {
  try {
    const supabase = getSupabase()
    const { data, error } = await supabase.from("favorites").select("song_id").eq("user_id", userId).eq("type", "song")

    if (error) {
      throw error
    }

    return data.map((item) => item.song_id)
  } catch (error) {
    console.error("Error getting user favorite songs:", error)
    return []
  }
}

// Get user's favorite artists
export async function getUserFavoriteArtists(userId: string): Promise<string[]> {
  try {
    const supabase = getSupabase()
    const { data, error } = await supabase
      .from("favorites")
      .select("artist_id")
      .eq("user_id", userId)
      .eq("type", "artist")

    if (error) {
      throw error
    }

    return data.map((item) => item.artist_id)
  } catch (error) {
    console.error("Error getting user favorite artists:", error)
    return []
  }
}

