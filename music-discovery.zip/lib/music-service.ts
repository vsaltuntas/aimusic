import type { LastFmArtist, LastFmTrack, LastFmTag } from "./lastfm-api"

async function fetchFromApi<T>(endpoint: string, params: Record<string, string> = {}): Promise<T> {
  const queryParams = new URLSearchParams(params)
  const response = await fetch(`/api/lastfm?${queryParams.toString()}`)

  if (!response.ok) {
    const errorBody = await response.text()
    throw new Error(`API error: ${response.status} ${response.statusText}\nBody: ${errorBody}`)
  }

  return response.json()
}

export async function getTopTracks(limit = 10, page = 1): Promise<LastFmTrack[]> {
  try {
    return await fetchFromApi<LastFmTrack[]>("lastfm", {
      method: "getTopTracks",
      limit: limit.toString(),
      page: page.toString(),
    })
  } catch (error) {
    console.error("Error fetching top tracks:", error)
    throw error
  }
}

export async function getTopArtists(limit = 10, page = 1): Promise<LastFmArtist[]> {
  return fetchFromApi<LastFmArtist[]>("lastfm", {
    method: "getTopArtists",
    limit: limit.toString(),
    page: page.toString(),
  })
}

export async function getTracksByTag(tag: string, limit = 10, page = 1): Promise<LastFmTrack[]> {
  return fetchFromApi<LastFmTrack[]>("lastfm", {
    method: "getTracksByTag",
    tag,
    limit: limit.toString(),
    page: page.toString(),
  })
}

export async function getTopTags(limit = 50): Promise<LastFmTag[]> {
  return fetchFromApi<LastFmTag[]>("lastfm", {
    method: "getTopTags",
    limit: limit.toString(),
  })
}

export async function searchArtists(query: string, limit = 10, page = 1): Promise<LastFmArtist[]> {
  return fetchFromApi<LastFmArtist[]>("lastfm", {
    method: "searchArtists",
    query,
    limit: limit.toString(),
    page: page.toString(),
  })
}

export async function searchTracks(query: string, limit = 10, page = 1): Promise<LastFmTrack[]> {
  return fetchFromApi<LastFmTrack[]>("lastfm", {
    method: "searchTracks",
    query,
    limit: limit.toString(),
    page: page.toString(),
  })
}

export function getImageUrl(images: { "#text": string; size: string }[], size = "large"): string {
  const image = images.find((img) => img.size === size)
  return image?.["#text"] || "/placeholder.svg?height=300&width=300"
}

