"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { User } from "@/lib/db-service"
import { getCurrentUser, signIn, signOut, signUp } from "@/lib/auth-service"
import { createUser } from "@/lib/db-service"

type UserContextType = {
  user: User | null
  loading: boolean
  error: string | null
  login: (email: string, password: string) => Promise<User | null>
  register: (email: string, password: string, name: string) => Promise<User | null>
  logout: () => Promise<void>
}

const UserContext = createContext<UserContextType | undefined>(undefined)

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await getCurrentUser()
        setUser(currentUser)
      } catch (err) {
        console.error("Error loading user:", err)
        setError("Failed to load user")
      } finally {
        setLoading(false)
      }
    }

    loadUser()
  }, [])

  const login = async (email: string, password: string) => {
    setLoading(true)
    setError(null)

    try {
      const user = await signIn(email, password)
      setUser(user)
      return user
    } catch (err: any) {
      console.error("Login error:", err)
      setError(err.message || "Failed to login")
      return null
    } finally {
      setLoading(false)
    }
  }

  const register = async (email: string, password: string, name: string) => {
    setLoading(true)
    setError(null)

    try {
      const authUser = await signUp(email, password, name)

      if (authUser) {
        // Create user in our database
        const dbUser = await createUser(authUser)
        setUser(dbUser)
        return dbUser
      }

      return null
    } catch (err: any) {
      console.error("Registration error:", err)
      setError(err.message || "Failed to register")
      return null
    } finally {
      setLoading(false)
    }
  }

  const logout = async () => {
    setLoading(true)
    setError(null)

    try {
      await signOut()
      setUser(null)
    } catch (err: any) {
      console.error("Logout error:", err)
      setError(err.message || "Failed to logout")
    } finally {
      setLoading(false)
    }
  }

  return (
    <UserContext.Provider value={{ user, loading, error, login, register, logout }}>{children}</UserContext.Provider>
  )
}

export function useUser() {
  const context = useContext(UserContext)
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider")
  }
  return context
}

