/** @type {import('next').NextConfig} */
const nextConfig = {
  // Buraya herhangi bir özel yapılandırma eklenebilir
}

module.exports = nextConfig

