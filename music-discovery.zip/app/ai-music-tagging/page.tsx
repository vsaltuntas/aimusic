"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Sparkles, Music, RefreshCcw } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import AITaggingExplanation from "@/components/ai-tagging-explanation"

export default function AIMusicTaggingPage() {
  const [songInput, setSongInput] = useState("")
  const [tags, setTags] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [explanation, setExplanation] = useState("")
  const { toast } = useToast()

  const handleTagging = async () => {
    if (!songInput.trim()) {
      toast({
        title: "Error",
        description: "Please enter a song or artist name",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    setTags([])
    setExplanation("")

    try {
      const response = await fetch("/api/ai/music-tagging", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ input: songInput }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to generate tags")
      }

      if (!data.tags || !data.explanation) {
        throw new Error("Invalid response format")
      }

      setTags(data.tags)
      setExplanation(data.explanation)
    } catch (error) {
      console.error("Error generating tags:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate tags. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-3 rounded-full bg-primary/10 mb-4">
            <Music className="h-8 w-8 text-primary" />
            <Sparkles className="h-6 w-6 text-primary ml-1" />
          </div>
          <h1 className="text-4xl font-bold mb-2">AI Music Tagging System</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover the essence of any song or artist with our AI-powered tagging system.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Enter a Song or Artist</CardTitle>
            <CardDescription>Our AI will analyze and generate comprehensive tags for the music.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Input
                placeholder="e.g., 'Bohemian Rhapsody' by Queen or 'Taylor Swift'"
                value={songInput}
                onChange={(e) => setSongInput(e.target.value)}
              />
              <Button onClick={handleTagging} disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <RefreshCcw className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" />
                    Generate Tags
                  </>
                )}
              </Button>
            </div>
          </CardContent>
          {tags.length > 0 && (
            <CardFooter className="flex flex-col items-start">
              <h3 className="text-lg font-semibold mb-2">Generated Tags:</h3>
              <div className="flex flex-wrap gap-2">
                {tags.map((tag, index) => (
                  <Badge key={index} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
              {explanation && (
                <div className="mt-4">
                  <h3 className="text-lg font-semibold mb-2">Explanation:</h3>
                  <Textarea value={explanation} readOnly className="w-full h-40" />
                </div>
              )}
            </CardFooter>
          )}
        </Card>

        <AITaggingExplanation className="mt-8" />
      </div>
    </div>
  )
}

