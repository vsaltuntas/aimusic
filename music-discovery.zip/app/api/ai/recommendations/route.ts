import { NextResponse } from "next/server"
import { generateRecommendations } from "@/lib/ai-recommendation-service"
import { getTopTracks } from "@/lib/lastfm-api"

export async function POST(request: Request) {
  try {
    const { userId, prompt, energyLevel, experimentalLevel } = await request.json()

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    // Get some recent tracks from Last.fm as a fallback if user has no history
    const recentTracks = await getTopTracks(5)

    const recommendations = await generateRecommendations(userId, prompt, recentTracks, energyLevel, experimentalLevel)

    return NextResponse.json(recommendations)
  } catch (error) {
    console.error("Error generating recommendations:", error)
    return NextResponse.json({ error: "Failed to generate recommendations" }, { status: 500 })
  }
}

