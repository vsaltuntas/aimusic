import { NextResponse } from "next/server"
import Anthropic from "@anthropic-ai/sdk"

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

export async function POST(request: Request) {
  try {
    const { input } = await request.json()

    if (!input) {
      return NextResponse.json({ error: "Input is required" }, { status: 400 })
    }

    if (!process.env.ANTHROPIC_API_KEY) {
      console.error("Anthropic API key is not set")
      return NextResponse.json({ error: "Server configuration error" }, { status: 500 })
    }

    const prompt = `
      Analyze the following song or artist: "${input}"
      
      Generate a comprehensive list of 10-20 highly descriptive, comma-separated keywords (tags) that accurately define the sound, style, instrumentation, and emotional impact of the music.
      
      Consider the following factors:
      1. Primary genre and subgenres
      2. Tempo and rhythmic structure
      3. Instrumentation and production style
      4. Vocal style and techniques
      5. Lyrical themes and emotional tone
      6. Cultural and historical context
      7. Usage context and listening experience
      
      Also, provide a brief explanation of why you chose these tags and how they relate to the music.
      
      Format your response as a JSON object with two keys: "tags" (an array of strings) and "explanation" (a string).
    `

    let completion
    try {
      completion = await anthropic.completions.create({
        model: "claude-2",
        prompt: `Human: ${prompt}\n\nAssistant:`,
        max_tokens_to_sample: 1000,
        temperature: 0.7,
      })
    } catch (anthropicError) {
      console.error("Anthropic API error:", anthropicError)
      return NextResponse.json(
        { error: "Error calling Anthropic API", details: anthropicError.message },
        { status: 500 },
      )
    }

    const content = completion.completion
    if (!content) {
      console.error("No content in Anthropic response")
      return NextResponse.json({ error: "Invalid response from AI" }, { status: 500 })
    }

    let result
    try {
      // Remove any leading/trailing whitespace and ensure we're parsing valid JSON
      const jsonString = content.trim().replace(/^```json\s*|\s*```$/g, "")
      result = JSON.parse(jsonString)
    } catch (parseError) {
      console.error("Error parsing Anthropic response:", content)
      return NextResponse.json({ error: "Invalid response format from AI", details: content }, { status: 500 })
    }

    if (!result.tags || !result.explanation) {
      console.error("Missing tags or explanation in result:", result)
      return NextResponse.json({ error: "Incomplete response from AI" }, { status: 500 })
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Unexpected error:", error)
    return NextResponse.json({ error: "An unexpected error occurred", details: error.message }, { status: 500 })
  }
}

