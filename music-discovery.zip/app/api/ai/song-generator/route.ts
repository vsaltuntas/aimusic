import { NextResponse } from "next/server"
import { generateSongIdea } from "@/lib/ai-recommendation-service"

export async function POST(request: Request) {
  try {
    const { prompt, genre, mood, structure, complexity } = await request.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    const songIdea = await generateSongIdea(prompt, genre, mood, structure, complexity)

    if (!songIdea) {
      return NextResponse.json({ error: "Failed to generate song idea" }, { status: 500 })
    }

    return NextResponse.json(songIdea)
  } catch (error) {
    console.error("Error generating song idea:", error)
    return NextResponse.json({ error: "Failed to generate song idea" }, { status: 500 })
  }
}

