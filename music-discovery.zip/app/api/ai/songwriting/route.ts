import { NextResponse } from "next/server"
import Anthropic from "@anthropic-ai/sdk"

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

export async function POST(request: Request) {
  try {
    const { artist, referenceTrack, genre, structure } = await request.json()

    if (!artist || !referenceTrack || !genre || !structure) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    if (!process.env.ANTHROPIC_API_KEY) {
      console.error("Anthropic API key is not set")
      return NextResponse.json({ error: "Server configuration error" }, { status: 500 })
    }

    const prompt = `
      As an AI songwriting assistant, create a high-quality song based on the following information:

      Artist: ${artist}
      Reference Track: ${referenceTrack}
      Genre: ${genre}
      Desired Structure: ${structure}

      Follow these steps to create the song:

      1. Analyze the artist's style and the reference track, considering:
         - Primary genre and subgenres
         - Emotional tone
         - Instrumentation and production style
         - Tempo and rhythmic feel
         - Vocal delivery and flow
         - Lyrical themes and common phrases

      2. Generate a detailed genre prompt based on your analysis.

      3. Structure the song according to the desired structure, ensuring proper flow and emotional build-up.

      4. Write powerful lyrics that are engaging, emotional, and properly structured. Use storytelling, strong rhyme and flow, metaphors, and catchy hooks where appropriate.

      5. Provide production and sound design suggestions, including mixing techniques and effects.

      6. Incorporate current trends and audience preferences to make the song relevant and appealing.

      Present the result as a JSON object with the following structure:
      {
        "analysis": {
          "style": "Brief description of the artist's style",
          "reference": "Analysis of the reference track"
        },
        "genrePrompt": "Detailed genre prompt",
        "structure": ["Array", "of", "song", "sections"],
        "lyrics": {
          "verse1": "Lyrics for verse 1",
          "chorus": "Lyrics for chorus"
        },
        "productionNotes": "Suggestions for production and sound design",
        "trends": "Notes on incorporated trends"
      }

      Ensure that the generated content is original, engaging, and fits the specified genre and artist style.
    `

    let completion
    try {
      completion = await anthropic.completions.create({
        model: "claude-2",
        prompt: `Human: ${prompt}\n\nAssistant:`,
        max_tokens_to_sample: 2000,
        temperature: 0.7,
      })
    } catch (anthropicError) {
      console.error("Anthropic API error:", anthropicError)
      return NextResponse.json(
        { error: "Error calling Anthropic API", details: anthropicError.message },
        { status: 500 },
      )
    }

    const content = completion.completion
    if (!content) {
      console.error("No content in Anthropic response")
      return NextResponse.json({ error: "Invalid response from AI" }, { status: 500 })
    }

    console.log("Raw Anthropic response:", content) // Log the raw response

    let result
    try {
      // Remove any leading/trailing whitespace and ensure we're parsing valid JSON
      const jsonString = content.trim().replace(/^```json\s*|\s*```$/g, "")
      result = JSON.parse(jsonString)
    } catch (parseError) {
      console.error("Error parsing Anthropic response:", content)
      return NextResponse.json({ error: "Invalid response format from AI", details: content }, { status: 500 })
    }

    if (
      !result.analysis ||
      !result.genrePrompt ||
      !result.structure ||
      !result.lyrics ||
      !result.productionNotes ||
      !result.trends
    ) {
      console.error("Incomplete result from AI:", result)
      return NextResponse.json({ error: "Incomplete response from AI" }, { status: 500 })
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Unexpected error:", error)
    return NextResponse.json({ error: "An unexpected error occurred", details: error.message }, { status: 500 })
  }
}

