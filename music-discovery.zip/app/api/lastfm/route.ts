import { NextResponse } from "next/server"
import * as LastFmAPI from "@/lib/lastfm-api"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const method = searchParams.get("method")

  try {
    let data

    switch (method) {
      case "getTopArtists":
        const artistLimit = Number.parseInt(searchParams.get("limit") || "10")
        const artistPage = Number.parseInt(searchParams.get("page") || "1")
        data = await LastFmAPI.getTopArtists(artistLimit, artistPage)
        break

      case "getTopTracks":
        const trackLimit = Number.parseInt(searchParams.get("limit") || "10")
        const trackPage = Number.parseInt(searchParams.get("page") || "1")
        data = await LastFmAPI.getTopTracks(trackLimit, trackPage)
        break

      case "getTracksByTag":
        const tag = searchParams.get("tag")
        const tagLimit = Number.parseInt(searchParams.get("limit") || "10")
        const tagPage = Number.parseInt(searchParams.get("page") || "1")
        if (!tag) {
          return NextResponse.json({ error: "Tag parameter is required" }, { status: 400 })
        }
        data = await LastFmAPI.getTracksByTag(tag, tagLimit, tagPage)
        break

      case "getTopTags":
        const tagListLimit = Number.parseInt(searchParams.get("limit") || "50")
        data = await LastFmAPI.getTopTags(tagListLimit)
        break

      case "searchArtists":
        const artistQuery = searchParams.get("query")
        const artistSearchLimit = Number.parseInt(searchParams.get("limit") || "10")
        const artistSearchPage = Number.parseInt(searchParams.get("page") || "1")
        if (!artistQuery) {
          return NextResponse.json({ error: "Query parameter is required" }, { status: 400 })
        }
        data = await LastFmAPI.searchArtists(artistQuery, artistSearchLimit, artistSearchPage)
        break

      case "searchTracks":
        const trackQuery = searchParams.get("query")
        const trackSearchLimit = Number.parseInt(searchParams.get("limit") || "10")
        const trackSearchPage = Number.parseInt(searchParams.get("page") || "1")
        if (!trackQuery) {
          return NextResponse.json({ error: "Query parameter is required" }, { status: 400 })
        }
        data = await LastFmAPI.searchTracks(trackQuery, trackSearchLimit, trackSearchPage)
        break

      default:
        return NextResponse.json({ error: "Invalid method" }, { status: 400 })
    }

    return NextResponse.json(data)
  } catch (error: any) {
    console.error("Last.fm API error:", error)
    return NextResponse.json({ error: error.message || "Failed to fetch data from Last.fm" }, { status: 500 })
  }
}

