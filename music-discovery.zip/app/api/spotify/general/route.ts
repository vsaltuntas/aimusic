import { NextResponse } from "next/server"
import { getNewReleases, getFeaturedPlaylists } from "@/lib/spotify-service"

export async function GET() {
  try {
    const [newReleases, featuredPlaylists] = await Promise.all([getNewReleases(), getFeaturedPlaylists()])

    return NextResponse.json({ newReleases, featuredPlaylists })
  } catch (error) {
    console.error("Error fetching Spotify data:", error)
    // Hata mesajını JSON formatında döndür
    return NextResponse.json({ error: "Failed to fetch Spotify data", details: error.message }, { status: 500 })
  }
}

