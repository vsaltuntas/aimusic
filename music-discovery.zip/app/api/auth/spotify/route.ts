import { NextResponse } from "next/server"
import { getSpotifyAuthUrl } from "@/lib/spotify-service"

export async function GET() {
  try {
    const authUrl = await getSpotifyAuthUrl()
    return NextResponse.json({ authUrl })
  } catch (error) {
    console.error("Error getting Spotify auth URL:", error)
    return NextResponse.json({ error: "Failed to get Spotify auth URL" }, { status: 500 })
  }
}

