import { NextResponse } from "next/server"
import { handleSpotifyCallback, getUserProfile, saveSpotifyUser } from "@/lib/spotify-service"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const code = searchParams.get("code")

  if (!code) {
    return NextResponse.json({ error: "No code provided" }, { status: 400 })
  }

  try {
    const tokenData = await handleSpotifyCallback(code)
    const spotifyProfile = await getUserProfile()
    const user = await saveSpotifyUser(spotifyProfile, tokenData)

    return NextResponse.json({ success: true, user })
  } catch (error) {
    console.error("Error handling Spotify callback:", error)
    return NextResponse.json({ error: "Failed to handle Spotify callback" }, { status: 500 })
  }
}

