"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Sparkles, Music, RefreshCcw, Download, Share2, Save } from "lucide-react"

export default function SongGeneratorPage() {
  const [prompt, setPrompt] = useState("")
  const [loading, setLoading] = useState(false)
  const [generated, setGenerated] = useState(false)

  // Mock data for generated song
  const mockSong = {
    title: "Midnight in the City",
    lyrics: `Verse 1:
Neon lights reflect in puddles on the ground
The city never sleeps, just keeps spinning 'round
Footsteps echo down these empty streets
Another sleepless night, another memory to keep

Chorus:
Midnight in the city
Where dreams and shadows play
Midnight in the city
Where night feels just like day

Verse 2:
Coffee shops still open, serving the night owls
Musicians in the subway, playing from their souls
Taxi cabs and sirens form the soundtrack
To this urban symphony that always calls me back

(Chorus)

Bridge:
The skyline's my horizon
The concrete's my home
In this urban jungle
I'm never alone

(Chorus x2)

Outro:
Midnight in the city
It's where I belong`,
    genre: "Indie Pop",
    mood: "Reflective",
    tempo: "Medium",
    key: "A minor",
  }

  const handleGenerate = () => {
    if (!prompt.trim()) return

    setLoading(true)

    // Simulate AI generation
    setTimeout(() => {
      setLoading(false)
      setGenerated(true)
    }, 2000)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-3 rounded-full bg-primary/10 mb-4">
            <Music className="h-8 w-8 text-primary" />
            <Sparkles className="h-6 w-6 text-primary ml-1" />
          </div>
          <h1 className="text-4xl font-bold mb-2">AI Song Generator</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Create original song lyrics, melodies, and ideas with the help of our AI music assistant.
          </p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Describe your song idea</CardTitle>
            <CardDescription>
              Tell us about the theme, mood, genre, or any specific elements you want in your song.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Textarea
              placeholder="e.g., 'A melancholic indie folk song about finding hope in difficult times' or 'An upbeat pop song about summer adventures with friends'"
              className="min-h-[120px]"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Genre</Label>
                <Select defaultValue="any">
                  <SelectTrigger>
                    <SelectValue placeholder="Select genre" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any genre</SelectItem>
                    <SelectItem value="pop">Pop</SelectItem>
                    <SelectItem value="rock">Rock</SelectItem>
                    <SelectItem value="indie">Indie</SelectItem>
                    <SelectItem value="folk">Folk</SelectItem>
                    <SelectItem value="electronic">Electronic</SelectItem>
                    <SelectItem value="hip-hop">Hip Hop</SelectItem>
                    <SelectItem value="r-and-b">R&B</SelectItem>
                    <SelectItem value="country">Country</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Mood</Label>
                <Select defaultValue="any">
                  <SelectTrigger>
                    <SelectValue placeholder="Select mood" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any mood</SelectItem>
                    <SelectItem value="happy">Happy</SelectItem>
                    <SelectItem value="sad">Sad</SelectItem>
                    <SelectItem value="energetic">Energetic</SelectItem>
                    <SelectItem value="calm">Calm</SelectItem>
                    <SelectItem value="romantic">Romantic</SelectItem>
                    <SelectItem value="nostalgic">Nostalgic</SelectItem>
                    <SelectItem value="angry">Angry</SelectItem>
                    <SelectItem value="hopeful">Hopeful</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Song Structure</Label>
                <Select defaultValue="verse-chorus">
                  <SelectTrigger>
                    <SelectValue placeholder="Select structure" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="verse-chorus">Verse-Chorus</SelectItem>
                    <SelectItem value="verse-chorus-bridge">Verse-Chorus-Bridge</SelectItem>
                    <SelectItem value="aaba">AABA (32-bar form)</SelectItem>
                    <SelectItem value="aabc">AABC</SelectItem>
                    <SelectItem value="through-composed">Through-composed</SelectItem>
                    <SelectItem value="freestyle">Freestyle</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Tempo</Label>
                <Select defaultValue="medium">
                  <SelectTrigger>
                    <SelectValue placeholder="Select tempo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="slow">Slow</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="fast">Fast</SelectItem>
                    <SelectItem value="variable">Variable</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label>Complexity</Label>
                <span className="text-sm text-muted-foreground">Moderate</span>
              </div>
              <Slider defaultValue={[50]} max={100} step={1} />
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleGenerate} disabled={loading || !prompt.trim()} className="w-full gap-2">
              {loading ? (
                <>
                  <RefreshCcw className="h-4 w-4 animate-spin" />
                  Generating song...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  Generate Song
                </>
              )}
            </Button>
          </CardFooter>
        </Card>

        {generated && (
          <div className="space-y-8">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-2xl">{mockSong.title}</CardTitle>
                    <CardDescription>AI-generated song based on your prompt</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Badge>{mockSong.genre}</Badge>
                    <Badge variant="outline">{mockSong.mood}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="lyrics">
                  <TabsList className="grid w-full max-w-md mx-auto grid-cols-3 mb-4">
                    <TabsTrigger value="lyrics">Lyrics</TabsTrigger>
                    <TabsTrigger value="chords">Chords</TabsTrigger>
                    <TabsTrigger value="melody">Melody</TabsTrigger>
                  </TabsList>

                  <TabsContent value="lyrics">
                    <div className="bg-muted p-4 rounded-md whitespace-pre-line">{mockSong.lyrics}</div>
                  </TabsContent>

                  <TabsContent value="chords">
                    <div className="bg-muted p-4 rounded-md">
                      <p className="mb-2 font-medium">Key: {mockSong.key}</p>
                      <div className="space-y-4">
                        <div>
                          <p className="font-medium mb-1">Verse:</p>
                          <p>Am - C - G - D</p>
                        </div>
                        <div>
                          <p className="font-medium mb-1">Chorus:</p>
                          <p>F - C - G - Am</p>
                        </div>
                        <div>
                          <p className="font-medium mb-1">Bridge:</p>
                          <p>Dm - Am - E - Am</p>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="melody">
                    <div className="bg-muted p-4 rounded-md text-center">
                      <p className="mb-4">Melody visualization coming soon!</p>
                      <p className="text-sm text-muted-foreground">
                        We're working on adding interactive melody playback and visualization.
                      </p>
                    </div>
                  </TabsContent>
                </Tabs>

                <div className="grid gap-4 md:grid-cols-3 mt-6">
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Tempo</p>
                    <p className="text-sm text-muted-foreground">{mockSong.tempo} (110 BPM)</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Key</p>
                    <p className="text-sm text-muted-foreground">{mockSong.key}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Structure</p>
                    <p className="text-sm text-muted-foreground">Verse-Chorus-Verse-Chorus-Bridge-Chorus</p>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-wrap gap-3">
                <Button className="gap-2">
                  <Save className="h-4 w-4" /> Save to Library
                </Button>
                <Button variant="outline" className="gap-2">
                  <Download className="h-4 w-4" /> Export
                </Button>
                <Button variant="outline" className="gap-2">
                  <Share2 className="h-4 w-4" /> Share
                </Button>
                <Button variant="outline" className="gap-2 ml-auto">
                  <RefreshCcw className="h-4 w-4" /> Regenerate
                </Button>
              </CardFooter>
            </Card>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold">Customize Your Song</h2>
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="song-title">Song Title</Label>
                    <Input id="song-title" defaultValue={mockSong.title} />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="song-lyrics">Edit Lyrics</Label>
                    <Textarea id="song-lyrics" defaultValue={mockSong.lyrics} className="min-h-[300px] font-mono" />
                  </div>

                  <div className="flex justify-end">
                    <Button>Save Changes</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

