"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useUser } from "@/context/user-context"
import { useToast } from "@/components/ui/use-toast"

export default function SpotifyCallback() {
  const router = useRouter()
  const { updateUser } = useUser()
  const { toast } = useToast()

  useEffect(() => {
    const handleCallback = async () => {
      const urlParams = new URLSearchParams(window.location.search)
      const code = urlParams.get("code")

      if (code) {
        try {
          const response = await fetch(`/api/auth/callback/spotify?code=${code}`)
          const data = await response.json()

          if (data.success) {
            // Update user context with Spotify data
            updateUser(data.user)
            toast({
              title: "Success",
              description: "Successfully logged in with Spotify!",
            })
            router.push("/dashboard")
          } else {
            throw new Error("Failed to authenticate with Spotify")
          }
        } catch (error) {
          console.error("Error handling Spotify callback:", error)
          toast({
            title: "Error",
            description: "Failed to complete Spotify authentication. Please try again.",
            variant: "destructive",
          })
          router.push("/login")
        }
      } else {
        toast({
          title: "Error",
          description: "No authentication code received from Spotify.",
          variant: "destructive",
        })
        router.push("/login")
      }
    }

    handleCallback()
  }, [router, updateUser, toast])

  return (
    <div className="flex items-center justify-center min-h-screen">
      <p>Processing Spotify login...</p>
    </div>
  )
}

