"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Sparkles, Music, RefreshCcw } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export default function AISongwritingPage() {
  const [artist, setArtist] = useState("")
  const [referenceTrack, setReferenceTrack] = useState("")
  const [genre, setGenre] = useState("")
  const [structure, setStructure] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [debugInfo, setDebugInfo] = useState<string>("")
  const { toast } = useToast()

  const handleSongwriting = async () => {
    if (!artist || !referenceTrack || !genre || !structure) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    setResult(null)
    setDebugInfo("")

    try {
      const response = await fetch("/api/ai/songwriting", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ artist, referenceTrack, genre, structure }),
      })

      const rawResponse = await response.text()
      console.log("API ham yanıtı:", rawResponse)
      setDebugInfo((prevInfo) => prevInfo + `API ham yanıtı: ${rawResponse}\n\n`)

      let jsonData
      try {
        jsonData = JSON.parse(rawResponse)
        console.log("JSON olarak parse edilen veri:", jsonData)
        setDebugInfo((prevInfo) => prevInfo + `JSON olarak parse edilen veri: ${JSON.stringify(jsonData, null, 2)}\n\n`)

        if (!response.ok) {
          throw new Error(jsonData.error || "Failed to generate song")
        }

        setResult(jsonData)
      } catch (jsonError) {
        console.error("JSON parse hatası:", jsonError)
        console.error("Geçersiz JSON yanıtı:", rawResponse)
        setDebugInfo(
          (prevInfo) => prevInfo + `JSON parse hatası: ${jsonError}\nGeçersiz JSON yanıtı: ${rawResponse}\n\n`,
        )
        throw new Error("API'den geçersiz yanıt formatı alındı. Yanıt JSON değil.")
      }
    } catch (error) {
      console.error("Şarkı oluşturma hatası:", error)
      setDebugInfo((prevInfo) => prevInfo + `Şarkı oluşturma hatası: ${error}\n\n`)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate song. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-3 rounded-full bg-primary/10 mb-4">
            <Music className="h-8 w-8 text-primary" />
            <Sparkles className="h-6 w-6 text-primary ml-1" />
          </div>
          <h1 className="text-4xl font-bold mb-2">AI Songwriting System</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Create high-quality, genre-accurate songs using our advanced AI system.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Song Parameters</CardTitle>
            <CardDescription>Enter the details for your AI-generated song.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div className="space-y-2">
                <label htmlFor="artist" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed">
                  Artist
                </label>
                <Input
                  id="artist"
                  placeholder="Enter artist name"
                  value={artist}
                  onChange={(e) => setArtist(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label
                  htmlFor="referenceTrack"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed"
                >
                  Reference Track
                </label>
                <Input
                  id="referenceTrack"
                  placeholder="Enter reference track name"
                  value={referenceTrack}
                  onChange={(e) => setReferenceTrack(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="genre" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed">
                  Genre
                </label>
                <Input id="genre" placeholder="Enter genre" value={genre} onChange={(e) => setGenre(e.target.value)} />
              </div>
              <div className="space-y-2">
                <label
                  htmlFor="structure"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed"
                >
                  Structure
                </label>
                <Input
                  id="structure"
                  placeholder="Enter song structure (e.g., Verse-Chorus-Verse-Bridge-Chorus)"
                  value={structure}
                  onChange={(e) => setStructure(e.target.value)}
                />
              </div>
              <Button onClick={handleSongwriting} disabled={loading}>
                {loading ? (
                  <>
                    <RefreshCcw className="mr-2 h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>Generate Song</>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {result && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Generated Song</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea value={result.lyrics} readOnly className="w-full h-64" />
            </CardContent>
          </Card>
        )}

        {debugInfo && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Debug Information</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea value={debugInfo} readOnly className="w-full h-64 font-mono text-sm" />
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

