import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import GenreExplorerLastFm from "@/components/genre-explorer-lastfm"
import TrendingTracks from "@/components/trending-tracks"
import TrendingArtists from "@/components/trending-artists"
import MusicInsights from "@/components/music-insights"
import { FileMusicIcon as MusicNote, Sparkles } from "lucide-react"
import Link from "next/link"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-6">
      <section className="mb-10">
        <div className="flex flex-col items-center text-center mb-8 space-y-4">
          <div className="flex items-center justify-center p-3 rounded-full bg-primary/10 mb-2">
            <MusicNote className="h-8 w-8 text-primary" />
            <Sparkles className="h-6 w-6 text-primary ml-1" />
          </div>
          <h1 className="text-4xl font-bold tracking-tight">Discover Your Next Favorite Song</h1>
          <p className="text-xl text-muted-foreground max-w-2xl">
            Our AI learns your music taste and recommends new artists, albums, and songs tailored just for you.
          </p>
          <div className="flex gap-4 mt-4">
            <Button size="lg" asChild>
              <Link href="/ai-recommendations">Get Recommendations</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/song-generator">Generate Songs</Link>
            </Button>
          </div>
        </div>
      </section>

      <Tabs defaultValue="discover" className="mb-12">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-3 mb-8">
          <TabsTrigger value="discover">Discover</TabsTrigger>
          <TabsTrigger value="trending">Trending</TabsTrigger>
          <TabsTrigger value="genres">Genres</TabsTrigger>
        </TabsList>
        <TabsContent value="discover">
          <div className="space-y-12">
            <TrendingTracks />
            <TrendingArtists />
          </div>
        </TabsContent>
        <TabsContent value="trending">
          <TrendingTracks />
        </TabsContent>
        <TabsContent value="genres">
          <GenreExplorerLastFm />
        </TabsContent>
      </Tabs>

      <section className="mb-12">
        <h2 className="text-3xl font-bold mb-6">Music Insights</h2>
        <Card>
          <CardContent className="p-6">
            <MusicInsights />
          </CardContent>
        </Card>
      </section>
    </div>
  )
}

