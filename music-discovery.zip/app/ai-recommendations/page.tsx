"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Sparkles, Music, Headphones, Mic, ThumbsUp, ThumbsDown } from "lucide-react"
import Image from "next/image"
import AIRecommendationForm from "@/components/ai-recommendation-form"
import type { AIRecommendation } from "@/lib/ai-recommendation-service"
import { useToast } from "@/components/ui/use-toast"
import { searchArtists, searchTracks } from "@/lib/music-service"
import type { LastFmArtist, LastFmTrack } from "@/lib/lastfm-api"
import { getImageUrl } from "@/lib/music-service"

export default function AIRecommendationsPage() {
  const { toast } = useToast()
  const [recommendations, setRecommendations] = useState<AIRecommendation | null>(null)
  const [trackResults, setTrackResults] = useState<LastFmTrack[]>([])
  const [artistResults, setArtistResults] = useState<LastFmArtist[]>([])
  const [loadingTracks, setLoadingTracks] = useState(false)
  const [loadingArtists, setLoadingArtists] = useState(false)

  const handleRecommendationsGenerated = async (data: AIRecommendation) => {
    setRecommendations(data)

    // Fetch real track data from Last.fm
    setLoadingTracks(true)
    try {
      const trackPromises = data.tracks.map((track) =>
        searchTracks(`${track.name} ${track.artist}`, 1).then((results) => results[0] || null),
      )
      const results = await Promise.all(trackPromises)
      setTrackResults(results.filter(Boolean))
    } catch (error) {
      console.error("Error fetching track data:", error)
    } finally {
      setLoadingTracks(false)
    }

    // Fetch real artist data from Last.fm
    setLoadingArtists(true)
    try {
      const artistPromises = data.artists.map((artist) =>
        searchArtists(artist.name, 1).then((results) => results[0] || null),
      )
      const results = await Promise.all(artistPromises)
      setArtistResults(results.filter(Boolean))
    } catch (error) {
      console.error("Error fetching artist data:", error)
    } finally {
      setLoadingArtists(false)
    }
  }

  const handleFeedback = (type: "positive" | "negative") => {
    // In a real app, this would send feedback to the server
    toast({
      title: "Feedback Recorded",
      description:
        type === "positive"
          ? "Thanks! We'll use this to improve your recommendations."
          : "Thanks for the feedback. We'll try to do better next time.",
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-3 rounded-full bg-primary/10 mb-4">
            <Sparkles className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-4xl font-bold mb-2">AI Music Recommendations</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Describe your mood, preferences, or the kind of music you're looking for, and our AI will generate
            personalized recommendations.
          </p>
        </div>

        <AIRecommendationForm onRecommendationsGenerated={handleRecommendationsGenerated} />

        {recommendations && (
          <div className="space-y-8 mt-8">
            <Tabs defaultValue="tracks">
              <TabsList className="grid w-full max-w-md mx-auto grid-cols-3 mb-8">
                <TabsTrigger value="tracks" className="gap-1">
                  <Music className="h-4 w-4" /> Tracks
                </TabsTrigger>
                <TabsTrigger value="artists" className="gap-1">
                  <Mic className="h-4 w-4" /> Artists
                </TabsTrigger>
                <TabsTrigger value="playlist" className="gap-1">
                  <Headphones className="h-4 w-4" /> Playlist
                </TabsTrigger>
              </TabsList>

              <TabsContent value="tracks">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {loadingTracks
                    ? Array(3)
                        .fill(0)
                        .map((_, i) => (
                          <Card key={i} className="animate-pulse">
                            <CardContent className="p-0">
                              <div className="bg-muted aspect-square w-full"></div>
                              <div className="p-4 space-y-2">
                                <div className="h-5 bg-muted rounded"></div>
                                <div className="h-4 bg-muted rounded w-3/4"></div>
                                <div className="h-16 bg-muted rounded mt-2"></div>
                                <div className="flex justify-between mt-2">
                                  <div className="h-8 bg-muted rounded w-20"></div>
                                  <div className="flex gap-2">
                                    <div className="h-8 w-8 bg-muted rounded-full"></div>
                                    <div className="h-8 w-8 bg-muted rounded-full"></div>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))
                    : recommendations.tracks.map((track, index) => {
                        const lastFmTrack = trackResults[index]
                        return (
                          <Card key={index}>
                            <CardContent className="p-0">
                              {lastFmTrack ? (
                                <div className="relative aspect-square">
                                  <Image
                                    src={getImageUrl(lastFmTrack.image) || "/placeholder.svg"}
                                    alt={track.name}
                                    fill
                                    className="object-cover"
                                  />
                                </div>
                              ) : (
                                <div className="aspect-square bg-muted flex items-center justify-center">
                                  <Music className="h-12 w-12 text-muted-foreground" />
                                </div>
                              )}
                              <div className="p-4">
                                <h3 className="font-bold text-lg">{track.name}</h3>
                                <p className="text-muted-foreground">{track.artist}</p>
                                <div className="flex items-center gap-2 my-2">
                                  <Badge variant="secondary">{track.matchScore}% Match</Badge>
                                </div>
                                <p className="text-sm mt-2">{track.reason}</p>
                                <div className="flex justify-between items-center mt-4">
                                  {lastFmTrack && (
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => window.open(lastFmTrack.url, "_blank")}
                                    >
                                      View on Last.fm
                                    </Button>
                                  )}
                                  <div className="flex gap-1 ml-auto">
                                    <Button size="icon" variant="ghost">
                                      <ThumbsUp className="h-4 w-4" />
                                    </Button>
                                    <Button size="icon" variant="ghost">
                                      <ThumbsDown className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        )
                      })}
                </div>
              </TabsContent>

              <TabsContent value="artists">
                <div className="grid gap-6 md:grid-cols-2">
                  {loadingArtists
                    ? Array(2)
                        .fill(0)
                        .map((_, i) => (
                          <Card key={i} className="animate-pulse">
                            <CardContent className="p-0">
                              <div className="flex flex-col md:flex-row">
                                <div className="bg-muted w-full md:w-1/3 aspect-square"></div>
                                <div className="p-4 md:w-2/3 space-y-2">
                                  <div className="h-5 bg-muted rounded"></div>
                                  <div className="h-4 bg-muted rounded w-3/4"></div>
                                  <div className="flex flex-wrap gap-2 my-2">
                                    <div className="h-6 bg-muted rounded w-16"></div>
                                    <div className="h-6 bg-muted rounded w-20"></div>
                                  </div>
                                  <div className="h-16 bg-muted rounded"></div>
                                  <div className="flex gap-2 mt-2">
                                    <div className="h-8 bg-muted rounded w-24"></div>
                                    <div className="h-8 bg-muted rounded w-20"></div>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))
                    : recommendations.artists.map((artist, index) => {
                        const lastFmArtist = artistResults[index]
                        return (
                          <Card key={index}>
                            <CardContent className="p-0">
                              <div className="flex flex-col md:flex-row">
                                {lastFmArtist ? (
                                  <div className="relative w-full md:w-1/3 aspect-square md:aspect-auto">
                                    <Image
                                      src={getImageUrl(lastFmArtist.image) || "/placeholder.svg"}
                                      alt={artist.name}
                                      fill
                                      className="object-cover"
                                    />
                                  </div>
                                ) : (
                                  <div className="w-full md:w-1/3 aspect-square md:aspect-auto bg-muted flex items-center justify-center">
                                    <Mic className="h-12 w-12 text-muted-foreground" />
                                  </div>
                                )}
                                <div className="p-4 md:w-2/3">
                                  <h3 className="font-bold text-lg mb-1">{artist.name}</h3>
                                  <Badge variant="secondary" className="mb-3">
                                    {artist.matchScore}% Match
                                  </Badge>
                                  <p className="text-sm mb-4">{artist.reason}</p>
                                  <div className="flex gap-2">
                                    {lastFmArtist && (
                                      <Button size="sm" onClick={() => window.open(lastFmArtist.url, "_blank")}>
                                        View on Last.fm
                                      </Button>
                                    )}
                                    <Button size="sm" variant="outline">
                                      Add to Favorites
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        )
                      })}
                </div>
              </TabsContent>

              <TabsContent value="playlist">
                <Card>
                  <CardHeader>
                    <CardTitle>{recommendations.playlist.name}</CardTitle>
                    <CardDescription>{recommendations.playlist.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-sm font-medium mb-2">Mood:</h4>
                        <div className="flex flex-wrap gap-2">
                          {recommendations.playlist.mood.map((mood, i) => (
                            <Badge key={i}>{mood}</Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium mb-2">Recommended Genres:</h4>
                        <div className="space-y-3">
                          {recommendations.genres.map((genre, i) => (
                            <div key={i} className="bg-muted p-3 rounded-md">
                              <div className="flex justify-between items-center mb-1">
                                <h5 className="font-medium">{genre.name}</h5>
                                <Badge variant="outline">{genre.matchScore}% Match</Badge>
                              </div>
                              <p className="text-sm text-muted-foreground">{genre.reason}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Create Playlist</Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>

            <div className="text-center space-y-4">
              <h3 className="text-lg font-medium">How were these recommendations?</h3>
              <div className="flex justify-center gap-4">
                <Button variant="outline" className="gap-2" onClick={() => handleFeedback("negative")}>
                  <ThumbsDown className="h-4 w-4" /> Not for me
                </Button>
                <Button className="gap-2" onClick={() => handleFeedback("positive")}>
                  <ThumbsUp className="h-4 w-4" /> Love these!
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Your feedback helps our AI learn your preferences better.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

